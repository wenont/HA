public class UnknownKeyException extends Exception{
    
    /**
     * Constructs an {@code UnknowKeyException} with {@code null}
     * as its error detail message.
     */
    public UnknownKeyException() {
        super();
    }
    
    
}
