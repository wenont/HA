public interface WritableMap<K, V> extends ReadableMap<K, V>{

    void put(K key, V value);
    
}
